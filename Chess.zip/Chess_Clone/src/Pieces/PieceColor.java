package Pieces;

public enum PieceColor {
    WHITE,
    BLACK
}